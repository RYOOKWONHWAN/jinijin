const baseUrl = 'http://localhost:8090';

export { baseUrl };
