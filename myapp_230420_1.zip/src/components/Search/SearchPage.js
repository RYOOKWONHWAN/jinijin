import SearchList from './SearchList';

const SearchPage = () => {
  return (
    <div className="page-header section">
      <SearchList />
    </div>
  );
};

export default SearchPage;
