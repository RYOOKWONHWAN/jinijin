const SearchList = () => {
  return (
    <div>
      <h2>검색 영화 리스트</h2>
    </div>
  );
};

export default SearchList;
