const AnalysisPage = () => {
  return (
    <div className="page-header section">
      <h2>취향분석 페이지</h2>
    </div>
  )
}

export default AnalysisPage;