import MovieList from './MovieList';

function IndexBody() {
  return (
    <>
      <div style={{ marginLeft: '5%', marginRight: '5%' }}>
        {/* SET-START */}
        <div style={{ height: '150px' }}></div>
        {/* TOP20 */}
        <div
          style={{
            width: 'auto',

            marginBottom: '10px',
          }}
        ></div>
        <div className='d-flex'>
          <MovieList></MovieList>
        </div>
        {/* SET_END */}

        {/* SET-START */}
        <div style={{ height: '150px' }}></div>
        {/* TOP20 */}
        <div
          style={{
            width: 'auto',

            marginBottom: '10px',
          }}
        ></div>
        <div className='d-flex'>
          <MovieList></MovieList>
        </div>
        {/* SET_END */}

        {/* SET-START */}
        <div style={{ height: '150px' }}></div>
        {/* TOP20 */}
        <div
          style={{
            width: 'auto',

            marginBottom: '10px',
          }}
        ></div>
        <div className='d-flex'>
          <MovieList></MovieList>
        </div>
        {/* SET_END */}

        {/* SET-START */}
        <div style={{ height: '150px' }}></div>
        {/* TOP20 */}
        <div
          style={{
            width: 'auto',

            marginBottom: '10px',
          }}
        ></div>
        <div className='d-flex'>
          <MovieList></MovieList>
        </div>
        {/* SET_END */}

        {/* SET-START */}
        <div style={{ height: '150px' }}></div>
        {/* TOP20 */}
        <div
          style={{
            width: 'auto',

            marginBottom: '10px',
          }}
        ></div>
        <div className='d-flex'>
          <MovieList></MovieList>
        </div>
        {/* SET_END */}
      </div>
    </>
  );
}

export default IndexBody;
