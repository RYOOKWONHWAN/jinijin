package com.example.admin.controller;

public class AdminController {

}
