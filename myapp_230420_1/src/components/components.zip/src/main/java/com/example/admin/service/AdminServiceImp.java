package com.example.admin.service;

public class AdminServiceImp {

}
