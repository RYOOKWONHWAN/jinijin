package com.example.list.service;

public interface ListService {

}
