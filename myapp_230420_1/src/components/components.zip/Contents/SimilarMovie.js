import { Col, Container, Row } from 'reactstrap';

const SimilarMovie = () => {
  return (
    <>
      <Container>
        <Row className="my-4">
          <Col md="9">
            <h3>비슷한 작품</h3>
          </Col>
        </Row>
      </Container>
    </>
  )
}

export default SimilarMovie;